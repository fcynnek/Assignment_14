package com.fcynnek.Assignment_14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
